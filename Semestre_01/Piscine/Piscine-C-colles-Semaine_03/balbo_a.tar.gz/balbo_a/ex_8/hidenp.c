int	my_putchar(char c)
{
	write(1, &c, 1);
}

int	hidenp(char *s1, char *s2)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (s1[i] && s2[j])
	{
		if (s1[i] == s2[j])
			i = i + 1;
		j = j + 1;
	}
	if (!(s1[i]))
		my_putchar('1');
	else
		my_putchar('0');
}

int	main(int argc, char **argv)
{
	if (argc == 3)
		hidenp(argv[1], argv[2]);
	my_putchar(10);
	return (0);
}
