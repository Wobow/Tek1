void	my_putchar(char c)
{
  write(1, &c, 1);
}

void	my_putstr(char *str)
{
  int	i;

  i = 0;
  while (str[i])
    {
      my_putchar(str[i]);
      i = i + 1;
    }
}


int	main(int argc, char **argv)
{
  if (argc >= 2)
    my_putstr(argv[1]);
  my_putchar(10);
}
