int	my_putchar(char c)
{
	write(1 , &c, 1);
}

int	my_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i = i + 1;
	return (i);
}

int	epur_str2(char *str, int start)
{
  int   i;
  int   tmp;
  int   fi;

  i = start;
  tmp = 0;
  fi = 0;
  while (str[i])
    {
      if (str[i] != 32 && str[i] != '\t')
        {
        if ((tmp == 32 || tmp == '\t') && fi)
           my_putchar(tmp);
        my_putchar(str[i]);
        fi = 1;
        }
      tmp = str[i];
      i = i + 1;
    }
}

int	rostring(char *str)
{
	int	i;
	int	j;

	j = 0;
	i = 0;
	while (j < 2 && str[i])
	{
		if ((i == 0  && str[i] != 32 && str[i] != '\t') ||  ((str[i] == 32 || str[i] == '\t') && str[i + 1] != 32 && str[i + 1] != '\t'))
			j = j + 1;
		i = i + 1;
	}
	if (i == my_strlen(str))
		epur_str2(str, 0);
	else
	{
		epur_str2(str, i);
		j = 0;	
		i = 0;
       		 while (j < 1 && str[i + 1])
       		 {
             		if ((i == 0  && str[i] != 32 && str[i] != '\t') ||  ((str[i] == 32 || str[i] == '\t') && str[i + 1] != 32 && str[i + 1] != '\t'))
				j = j + 1;
              		  i = i + 1;
    		 }
		if (str[0] != 32)
			i = i - 1;
		my_putchar(32);
		while (str[i] != 32)
		{
			my_putchar(str[i]);
			i = i + 1;
		}
	}
}	

int	main(int argc, char **argv)
{
	if (argc == 2)
		rostring(argv[1]);
	my_putchar(10);
}
