int	my_putchar(char c)
{
	write(1, &c, 1);
}

int	my_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		my_putchar(str[i]);
		i = i + 1;
	}
}

int	my_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i = i + 1;
	return (i);
}

int	half_str(char *str)
{
	int	i;

	i = 0;
	while (i < my_strlen(str))
	{
		if (!(i % 2))
			my_putchar(str[i]);
		i = i + 1;
	}
}

int	main(int argc, char **argv)
{
	int	i;

	i = 1;
	if (argc > 1)
	{
		while (i < argc)
		{
			half_str(argv[i]);
			my_putchar(10);
			i = i + 1;
		}	
	}	
	else
		my_putchar(10);
}
