int	my_putchar(char c)
{
  write(1, &c, 1);
}

int	my_putstr(char *str)
{
  int	i;

  i = 0;
  while (str[i])
    {
      my_putchar(str[i]);
      i = i + 1;
    }
}

int	my_char_isalpha(char c)
{
  if (c >= 'A' && c <= 'Z')
    return (1);
  else if (c >= 'a' && c <= 'z')
    return (1);
  return (0);
}

int	rotone(char *str)
{
  int	i;

  i = 0;
  while (str[i])
    {
      if (my_char_isalpha(str[i]))
	{
	  if ((!(str[i] - 90) || !(str[i] - 122)))
	    my_putchar(str[i] - 25);
	  else
	    my_putchar(str[i] + 1);
	}
      else
	my_putchar(str[i]);
      i = i + 1;
    }
}

int	main(int argc, char **argv)
{
  if (argc == 2)
    rotone(argv[1]);
  my_putchar(10);
  return (0);
}
