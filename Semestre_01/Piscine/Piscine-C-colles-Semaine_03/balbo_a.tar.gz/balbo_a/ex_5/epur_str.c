int	my_putchar(char c)
{
  write(1, &c, 1);
}

int	my_putstr(char *str)
{
  int	i;

  i = 0;
  while (str[i])
    {
      my_putchar(str[i]);
      i = i + 1;
    }
}

int	epur_str(char *str)
{
  int	i;
  int	tmp;
  int	fi;

  i = 0;
  tmp = 0;
  fi = 0;
  while (str[i])
    {
      if (str[i] != 32 && str[i] != '\t')
	{
	if ((tmp == 32 || tmp == '\t') && fi)
	   my_putchar(tmp);
        my_putchar(str[i]);
      	fi = 1;
	}
      tmp = str[i];	
      i = i + 1;
    }
}

int	main(int argc, char **argv)
{
  if (argc == 2)
    epur_str(argv[1]);
  my_putchar(10);
  return (0);
}
