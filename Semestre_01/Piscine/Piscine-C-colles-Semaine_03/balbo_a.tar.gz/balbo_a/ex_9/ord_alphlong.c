#include <stdlib.h>

int	my_putchar(char c)
{
	write(1, &c, 1);
}

int	my_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		my_putchar(str[i]);
		i = i + 1;
	}
}

int	my_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i = i + 1;
	return (i);
}

int	my_word(char *str)
{
	int	i;
	int	max;
	int	word;

	i = 0;
	max = 0;
	word = 0;
	while (str[i])
	{
		if (i == 0 && str[i] != 32)
			word = word + 1;
		else if (str[i - 1] == 32 && str[i] != 32)
			word = word + 1;
		i = i + 1; 
	}
	return (word);
}

int	aff_tab(char **tab, int i)
{
	int	k;
	int	tmp;

	k = 0;
	tmp = 0;
	while (k < i)
	{	
		if (my_strlen(tab[k]) >= tmp)
		{
			if (tmp != 0)	
				my_putchar(10);
			tmp = my_strlen(tab[k]) + 1;
		}
		else
		{
			my_putchar(32);
		}
		my_putstr(tab[k]);
		k = k + 1;
	}

}

int	is_superior(char c1, char c2)
{
	if (c1 >= 'A' && c1 <= 'Z' && c2 >= 'A' && c2 <= 'Z')
	{
		if (c1 > c2)
			return (1);
		if (c1 == c2)
			return (2);
		return (0);
	}
        if (c1 >= 'a' && c1 <= 'z' && c2 >= 'a' && c2 <= 'z')
	{
		if (c1 > c2)
			return (1);
		if (c1 == c2)
			return (2);
		return (0);
	}
        if (c1 >= 'A' && c1 <= 'Z' && c2 >= 'a' && c2 <= 'z')
	{
		if (c1 + 32 > c2)
			return (1);
		if (c1 + 32 == c2)
			return (2);
		return (0);
	}
        if (c1 >= 'a' && c1 <= 'z' && c2 >= 'A' && c2 <= 'Z')
	{
		if (c1 > c2 + 32)
			return (1);
		if (c1 == c2 + 32)
			return (2);
		return (0);
	}
	return (0);

}

int	ord_alphlong(char *str)
{
	char	**wordtab;
	int	i;
	int	j;
	int	k;
	char	*tmp;
	int	o;

	k = 0;
	i = 0;
	wordtab = malloc(sizeof(char*) * my_word(str));
	while (str[i])
	{
		wordtab[k] = malloc(sizeof(char) * 50);
		j = i;
		if (i == 0 && str[i] != 32 && str[j])
		{
			while (str[j] != 32)
			{
				wordtab[k][j - i] = str[j];
				j = j + 1;
			}
			k = k + 1; 
		}
		else if (str[i - 1] == 32 && str[i] != 32) 
		{
			while (str[j] != 32 && str[j])
			{
				wordtab[k][j - i] = str[j];
				j = j + 1;
			}
			k = k + 1;
		}
                i = i + 1;
	}
	k = 0;
	while (k < my_word(str) + 1)
        {
                i = 0;
		o = 0;
                while (i < my_word(str))
                {
			if (o < my_strlen(wordtab[i]) && my_strlen(wordtab[i + 1]))
			{
				if (is_superior(wordtab[i][o], wordtab[i + 1][o]) == 1)
				{
					my_putchar('z');
					tmp = wordtab[i];
					wordtab[i] = wordtab[i + 1];
					wordtab[i + 1] = tmp;
					i = i + 1;                       
				}
				else if (is_superior(wordtab[i][o], wordtab[i + 1][o]) == 2)
				{
					o = o + 1;
				}
				else
					i = i + 1;
			}
			else
				i = i + 1;
		}
		k = k + 1;
        }
	k = 0;
	while (k < my_word(str))
	{
		i = 0;
		while (i < my_word(str) - 1)
		{
			if (my_strlen(wordtab[i]) > my_strlen(wordtab[i + 1]))
			{
				tmp = wordtab[i];
				wordtab[i] = wordtab[i + 1];
				wordtab[i + 1] = tmp;
			}
			i = i + 1;	
		}
		k = k + 1;
	}
	aff_tab(wordtab, my_word(str));		
}

int	main(int argc, char **argv)
{
	if (argc == 2)
		ord_alphlong(argv[1]);
	my_putchar(10);
}
